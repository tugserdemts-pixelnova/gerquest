# Gerquest — Монгол гэр 3D аялал

Interactive 3D tour of a Mongolian ger (Three.js), in Mongolian and English.

- Scroll to explore the parts of the ger and answer a quiz at each station to collect them
- Collect all 9 parts, then build the ger yourself in the right order

## Run it
Open `index.html` in a browser — no build step needed.

## Live site (GitHub Pages)
Settings → Pages → Source: *Deploy from a branch* → `main` / root → Save.
